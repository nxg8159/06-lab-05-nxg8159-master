/* A few useful items are provided to you. You must write the rest. */

public class TollRecord implements Comparable<TollRecord>{

    /**
     * For printing toll records in reports
     * using {@link String#format(String, Object...)}
     */
    private static final String TOLL_RECORD_FORMAT = "[%11s] on #%2d, time %5d";
    private static final String OFF_FORMAT = "; off #%2d, time %5d";
    private int onExit;
    private int offExit;
    private int onTime;
    private int offTime;
    private String tag;

    /**
     * Value of uninitialized integer fields in this record
     */
    public static final int UNINITIALIZED = -1;

    public TollRecord(String tag, int onExit, int onTime){
        this.onExit = onExit;
        this.onTime = onTime;
        this.offExit = UNINITIALIZED;
        this.offTime = UNINITIALIZED;
        this.tag = tag;
    }

    public void setOffExit(int exit, int time){
        this.offExit = exit;
        this.offTime = time;
    }

    /*
    Getter for the tag
     */
    public String getTag(){
        return this.tag;
    }

    /**
     * Getter for onExit
     * @return
     */
    public int getOnExit(){
        return this.onExit;
    }

    /**
     * getter for onTime
     * @return
     */
    public int getOnTime(){
        return this.onTime;
    }

    /**
     * getter for offExit
     * @return
     */
    public int getOffExit(){
        return this.offExit;
    }

    /**
     * getter for offTime
     * @return
     */
    public int getOffTime(){
        return this.offTime;
    }

    /**
     * Computes the fare of one full ride on the NY highway system
     * @return
     */
    public double getFare(){
        if(TollSchedule.isValid(this.onExit) && TollSchedule.isValid(this.offExit)){
            return TollSchedule.getFare(this.onExit,this.offExit);
        }
        return 0;
    }

    /**
     * equals function
     * @param other object to be compared
     * @return are they equal?
     */
    public boolean equals(Object other){
        return (other instanceof TollRecord)&&(this.onTime == ((TollRecord) other).getOnTime())
                &&(this.tag.equals(((TollRecord) other).getTag()));
    }

    /**
     * simple toString
     * @return
     */
    public String toString(){
        return this.report();
    }

    /**
     * Returns a string for a report
     * @return
     */
    public String report(){
        return ("[" + tag + "]" + "on " + onExit + " , time " + onTime + "; off " + offExit + ", time " + offTime);
    }

    /**
     * Returns the hashcode of the individual tollride
     * @return
     */
    public int hashcode(){
        return tag.codePointCount(0,tag.length())*3601 + this.onTime;
    }

    /**
     * Provides a natural ordering for the tollreports
     * @param other
     * @return
     */
    public int compareTo(TollRecord other){
        return this.tag.compareTo(other.getTag());
    }
}
