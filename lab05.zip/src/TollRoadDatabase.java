/* A few useful items are provided to you. You must write the rest. */
import java.util.*;
import java.io.*;

public class TollRoadDatabase {
    /**
     * For printing floating point values in dollar/cents format. Example:
     * System.out.println( String.format( DOLLAR_FORMAT, 10.5 );  // $10.50
     */
    private static final String DOLLAR_FORMAT = "$%5.2f";
    private static final String SPEED_FORMAT = "%5.1f MpH";

    /**
     * Universal new line
     */
    private static final String NL = System.lineSeparator();

    /**
     * Conversion constant from minutes to hours
     */
    public static final double MINUTES_PER_HOUR = 60.0;

    /**
     * d
     * This toll road's speed limit, in miles per hour
     */
    public static final double SPEED_LIMIT = 65.0;
    private HashMap<Integer,TollRecord> completedMap;
    private HashMap<String,TollRecord> uncompletedMap;

    /**
     * Constructor
     */
    public TollRoadDatabase(String eventFileName) throws FileNotFoundException {
        completedMap = new HashMap();
        uncompletedMap = new HashMap();
        Scanner scanner = this.fileChecker(eventFileName);
        while (scanner.hasNextLine()) {
            String input = scanner.nextLine();
            String[] strings = input.split(",");
            List<String> itemList = Arrays.asList(strings);
            this.enterEvent(itemList.get(1), Integer.parseInt(itemList.get(2)), Integer.parseInt(itemList.get(0)));
        }
    }

    private Scanner fileChecker(String eventFileName) throws FileNotFoundException {
        return new Scanner(new File(eventFileName));
    }

    /**
     * Records a new vehicle passing through an exit
     *
     * @param tag
     * @param exit
     * @param time
     */
    private void enterEvent(String tag, int exit, int time) {
        if (uncompletedMap.containsKey(tag)) {
            TollRecord newToll = uncompletedMap.get(tag);
            uncompletedMap.remove(tag);
            newToll.setOffExit(exit, time);
            completedMap.put(newToll.hashcode(), newToll);
        } else {
            uncompletedMap.put(tag, new TollRecord(tag, exit, time));
        }
    }

    public void summaryReport() {
        System.out.println("Completed trips: " + this.completedMap.size());
    }

    /**
     * Lists all vehicles still on the road
     */
    public void onRoadReport() {
        Iterator it = this.uncompletedMap.entrySet().iterator();
        LinkedList<TollRecord> list = new LinkedList<>();
        while (it.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry) it.next();
            list.add((TollRecord) pair.getValue());
        }
        Collections.sort(list);
        System.out.println("Vehicles still on the road: ");
        for (int x = 0; x < list.size(); x++) {
            System.out.println(list.get(x).toString());
        }
    }

    /**
     * Prints out all the Bills for each trip
     * Sorting by hashcode should sort in the order described due to the way the hashcode is implemented
     */
    public void printBills() {
        Iterator it = this.completedMap.entrySet().iterator();
        LinkedList<TollRecord> list = new LinkedList<>();
        while (it.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry) it.next();
            list.add((TollRecord) pair.getValue());
        }
        Collections.sort(list);
        System.out.println("Bills for completed trips: ");
        for (int x = 0; x < list.size(); x++) {
            System.out.println(list.get(x).toString() + ", Bill: " + list.get(x).getFare());
        }
    }

    /**
     * Lists all the speeders on the Road
     */
    public void speederReport() {
        Iterator it = this.completedMap.entrySet().iterator();
        LinkedList<TollRecord> list = new LinkedList<>();
        while (it.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry) it.next();
            list.add((TollRecord) pair.getValue());
            System.out.println(pair);
        }
        Collections.sort(list);
        System.out.println("List of Speeders: ");
        for (int x = 0; x < list.size(); x++) {
            double speed = Math.abs((TollSchedule.getLocation((list.get(x)).getOffExit())
                    - TollSchedule.getLocation((list.get(x)).getOnExit())) /
                    (list.get(x).getOffTime() -
                            list.get(x).getOnTime()))*60;
            if (speed > 65) {
                System.out.println(list.get(x).toString() + ", " + speed + " mph");
            }
        }
    }

    /**
     * Prints a summary for a single customer
     *
     * @param tag
     */
    public void printCustSummary(String tag) {
        double totalFare = 0;
        Iterator it = this.completedMap.entrySet().iterator();
        LinkedList<TollRecord> list = new LinkedList<>();
        while (it.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry) it.next();
            list.add((TollRecord) pair.getValue());
        }
        for (int x = 0; x < list.size(); x++) {
            if (list.get(x).getTag().equals(tag)) {
                System.out.println(list.get(x).toString());
                totalFare += list.get(x).getFare();
            }
        }
        System.out.println("Total Fare: " + totalFare);

        if (uncompletedMap.containsKey(tag)) {
            System.out.println("Vehicle still on highway");
            System.out.println(uncompletedMap.get(tag).toString());
        }
    }

    public void printExitActivity(int exit) {
        Iterator it = this.completedMap.entrySet().iterator();
        LinkedList<TollRecord> list = new LinkedList<>();
        while (it.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry) it.next();
            list.add((TollRecord) pair.getValue());
        }
        Collections.sort(list);
        System.out.println("Completed trips passing through exit " + exit + ": ");
        for (int x = 0; x < list.size(); x++) {
            if (list.get(x).getOnExit() == exit || list.get(x).getOffExit() == exit) {
                System.out.println(list.get(x).toString());
            }
        }
        Iterator its = this.uncompletedMap.entrySet().iterator();
        LinkedList<TollRecord> lists = new LinkedList<>();
        while (its.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry) its.next();
            lists.add((TollRecord) pair.getValue());
        }
        Collections.sort(lists);
        System.out.println("Uncompleted trips passing through exit " + exit + ": ");
        for (int x = 0; x < lists.size(); x++) {
            if (lists.get(x).getOnExit() == exit) {
                System.out.println(lists.get(x).toString());
            }
        }
    }



public static void main(String[] args) throws FileNotFoundException {
    int decider = 0;
    TollRoadDatabase data = new TollRoadDatabase(args[0]);
    data.summaryReport();
    data.speederReport();
    data.onRoadReport();
    data.printBills();
    Scanner scan = new Scanner(System.in);
    while (decider != -1) {
        System.out.println("Please enter b to get a report for a specific car," +
                "e for an exit report, or q to terminate the program ");
        String choice = scan.next();
        if (choice.equals("q")) {
            decider = -1;
        } else if (choice.equals("e")) {
            System.out.println("Please enter the exit number: ");
            data.printExitActivity(scan.nextInt());
        } else if (choice.equals("b")) {
            System.out.println("Please enter the tag for the vehicle you would like to check out: ");
            data.printCustSummary(scan.next());
        } else {
            System.out.println("Invalid input. Try again.");
        }
    }
}
}